package com.dicoding.picodiploma.namanamanabi

data class Nabi(
    var name: String = "",
    var detail: String = "",
    var gambartulisan: Int = 0
)